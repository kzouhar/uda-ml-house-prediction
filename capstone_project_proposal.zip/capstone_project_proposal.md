# Machine Learning Engineer Nanodegree
# Capstone Proposal

Khalil Zouhar, June 12, 2013

## Proposal

The project is a newly added Kaggle competition: Predict House sales prices.

Competition details available at: https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/overview

### Domain Background

Prediction:

An accurate prediction on the house price is important to prospective homeowners,
developers, investors, appraisers, tax assessors and other real estate market stakeholders, such
as, mortgage lenders and insurers. 
There is no standard certified way to assess the price of house. Therefore, the availability of a house price prediction model using machine learning can help fill up an
important information gap and improve the efficiency of the real estate market 

### Problem Statement

#### Stakeholders: 
prospective homeowners,
developers, investors, appraisers, tax assessors and other real estate market stakeholders, such
as, mortgage lenders and insurers would like to predict house price.

#### Domain:
Real State Business, Banking Business, Insurance Business

#### Problem:
How to efficiently predict a house price?. There is an information gap when it came to house prediction. The information gap can be filled with using 
Machine learning techniques, thus driving real eastate efficiency.

### Datasets and Inputs

The dataset has records of 1460 house sold between 2010 and 2016 in Ames, Iowa. Each data record captures a list of 79 house features (ie: size, location) and the correspinding sale price.
House features are described in a separate file: data_description.txt

The dataset were compiled by Dean De Cok and collect the house sales in the area of Ames, Iowa.

The Data is available at: https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data

### Solution Statement

The goal here is to build a system that can predict a price of a given house based on house features. 
The data we have is a tabular data and the first solution that came ot mind is to use Decision trees.

Also, In this scenario, we are being asked to predict a numerical outcome. As result this is regression task.

Therefor this problem can be approached with tree machine learning models: Decision tree, random forest and gradient boosting machines.

I plan to use the decision tree as my baseline model then built on this experience to tune my candidate models.

Decision trees are easy to train and can give an insight on how to tune the hyperparameters.

### Benchmark Model

I will use the Kaggle leaderboard, in which the solutions are evaluated upon test data not made available to the competitors. In the leaderboard we can benchmark my results against solutions from other competitors.

### Evaluation Metrics

The evaluation metric is already defined by the competition to be Root-Mean-Squared-Error (RMSE).

The root-mean-square deviation (RMSD) or root-mean-square error (RMSE) is a frequently used measure of the differences between values (sample or population values) predicted by a model or an estimator and the values observed. The RMSD represents the square root of the second sample moment of the differences between predicted values and observed values or the quadratic mean of these differences.

https://en.wikipedia.org/wiki/Root-mean-square_deviation

### Project Design

#### Intended workflow:
![alt text](training_lifec_cycle.png "Training Life Cylce")

#### Data Analysis: 
Understand the dataset 

#### Data cleanup

- Remove duplicate record. Checking for missing values.
- Transform N/A to a category to a avoid errors. 
- Converting  date values to string value.
- Transform number encoded categories to string so the emphasize is not on the magnitude of the number but rather the category.

#### Features Transformation 
- Convert variables into features. 
- Standardize/normalize features, 
- Apply numerical transformations, 
- perform one-hot encoding.

#### Features Creation 
Analyse the possibility of deriving new features from the existing ones

#### Features Selection or Extraction
Not all 79 features influence the price. So we need extract the relevant features.

#### Machine Learning Model Selection (see the solution section for the motive behind choosing the algorithms below):

   - Decision Tree:  A tree algorithm used in machine learning to find patterns in data by learning decision rules.
   - Random Forest — A type of bagging method that plays on ‘the wisdom of crowds’ effect. It uses multiple independent decision trees in parallel to learn from data and aggregates their predictions for an outcome.
   - Gradient Boosting Machines — A type of boosting method that uses a combination of decision tree in series. Each tree is used to predict and correct the errors by the preceding tree additively.
   
   Random forests and gradient boosting can significantly improve the quality of weak decision trees. 
   They’re great algorithms to use if we  have small training data sets like in this case.

#### Training:
   
   At this stage we will teach our model using examples from the dataset. In the training stage we will tune the model hyperparameter. 
   Our goal at this stage if to find the optimal hyperparmater value that lower the model bias and model variance.

- Model bias:
Refers to models that under-fit the training data leading to poor predictive capacity on unseen data. Generally, the simpler the model the higher the bias.

- Model variance:
  Refers to Models that over-fit the training data leading to poor predictive capacity on unseen data. Generally, the more complexity in the model the higher the variance.
   
I plan to tune the following hyperparamaters:

   - max_depth — The maximum number of nodes for a given decision tree.
   - max_features — The size of the subset of features to consider for splitting at a node.
   - n_estimators — The number of trees used for boosting or aggregation. This hyperparameter only applies to the random forest and gradient boosting machines.
   - learning_rate — The learning rate acts to reduce the contribution of each tree. This only applies for gradient boosting machines.

For better hyperparameter tuning (to ovoid over-fitting and model bias) I will use the following techniques:
   
   - Grid search: Choosing the range of your hyperparameters is an iterative process. With more experience you’ll begin to get a feel for what ranges to set. The good news is once you’ve chosen your possible hyperparameter ranges, grid search allows you to test the model at every combination of those ranges. I’ll talk more about this in the next section.
   - Cross validation: Models are trained with a 5-fold cross validation. A technique that takes the entirety of your training data, randomly splits it into train and validation data sets over 5 iterations.

#### Evaluation
   At this stage we evaluate our selected machine learning models. Either we are happy with the results or we need to go trough to another cycle/iteration.  

#### Submit Results
   Finally, after few iterations of improving our select model we reach the optimal model and we are ready to submit our result.